//
//  main.m
//  JSBridge
//
//  Created by Dante Torres on 10-09-03.
//  Copyright Other Ocean Interactive 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
    
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, nil);
    [pool release];
    return retVal;
}
