PortalDemo
==========

Demonstrates how plugins in Alipay portal works
